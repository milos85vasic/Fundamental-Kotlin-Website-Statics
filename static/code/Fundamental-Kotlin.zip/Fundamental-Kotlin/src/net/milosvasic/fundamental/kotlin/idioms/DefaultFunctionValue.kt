package net.milosvasic.fundamental.kotlin.idioms

/**
 * Created by mvasic on 6/5/16.
 */
fun defaultValueExample(x: Int = 0, y: Int = 2){
// Further implementation ...
}