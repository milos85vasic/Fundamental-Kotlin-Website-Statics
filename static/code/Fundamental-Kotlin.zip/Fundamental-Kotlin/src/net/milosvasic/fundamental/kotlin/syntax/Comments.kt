package net.milosvasic.fundamental.kotlin.syntax

/**
 * Created by milosvasic on 6/4/16.
 */
// Single line comment

/* Multi-line
 * comment */
