package net.milosvasic.fundamental.kotlin.idioms

/**
 * Created by mvasic on 6/5/16.
 */
data class MyDataClass(val name: String, val age: Int) {}