package net.milosvasic.fundamental.kotlin.classes

/**
 * Created by milosvasic on 6/8/16.
 */
class CompanionObjectExample {
    companion object StaticObject {
        fun iAmStatic(){
            println("I am static!")
        }
    }
}