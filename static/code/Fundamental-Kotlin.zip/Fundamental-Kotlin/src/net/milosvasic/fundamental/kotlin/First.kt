package net.milosvasic.fundamental.kotlin

/**
 * Created by milosvasic on 6/4/16.
 */
fun main(args: Array<String>) {
    println("My first Kotlin application.")
}