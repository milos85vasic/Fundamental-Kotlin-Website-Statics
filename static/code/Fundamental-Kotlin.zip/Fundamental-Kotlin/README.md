# Fundamental Kotlin
Source code for the book: Fundamental Kotlin

Book website: http://www.fundamental-kotlin.com/
# About the Book
Reason I decided to write this book was my strong impression with this language. As I want as much as possible people to try it i decided to write this example-driven book. If any of you who read notice anything that is not correct in the code examples please report it to me (milos.vasic@fundamental-kotlin.com), I will check and apply the changes in code if needed. Since this is a new technology for me too it is possible that something may come up.

This is the first book edition, so my plans for the second edition are to update examples, polish it and extend it. Everybody is wellcome to participate so if you have a better example (alternative) to existing ones please email me. I will be more than happy to include your examples. 
